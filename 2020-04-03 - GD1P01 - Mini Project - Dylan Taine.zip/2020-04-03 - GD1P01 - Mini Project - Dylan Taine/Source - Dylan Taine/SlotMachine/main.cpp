#include <iostream>
#include <windows.h>
#include <conio.h>
#include <string>
#include <limits>
#include <ctime>
#include <cstdlib>



#undef max
using namespace std;

long totalcash = 2000; // Declaring all global variables here
char values[] = { '2','3','4','5','6','7' };
long betcash = 0;
long x3bet;
long x5bet;
long x10bet;
int menuopt; //This variable controls which menu option is chosen
short a, b, c;

int x3() // This function and the following two calculate wins and return the increased bet.
{
    x3bet = betcash * 3;
    totalcash = totalcash + x3bet;
    return (x3bet);
}

int x5()
{
    x5bet = betcash * 5;
    totalcash = totalcash + x5bet;
    return (x5bet);
}

int x10()
{
    x10bet = betcash * 10;
    totalcash = totalcash + x10bet;
    return (x10bet);
}

int losscash() // This function subtracts lost money when all numbers fail to match
{
    totalcash = totalcash - betcash;
    return (totalcash);
}

void menu() // Displaying main menu function
{
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 5);
    cout << endl << endl << endl << endl << endl << endl << endl << endl;
    cout << "                                                   ------------------------------------------------" << endl;
    cout << "                                                   |                  Balance: " << totalcash << "               |" << endl;
    cout << "                                                                                                   " << endl;
    cout << "                                                   |                                              |" << endl;
    cout << "                                                                      Play [1]                     " << endl;
    cout << "                                                   |                                              |" << endl;
    cout << "                                                                                                   " << endl;
    cout << "                                                   |                  Credits [2]                 |" << endl;
    cout << "                                                                                                   " << endl;
    cout << "                                                   |                                              |" << endl;
    cout << "                                                                      Quit [3]                     " << endl;
    cout << "                                                   |                                              |" << endl;
    cout << "                                                   ------------------------------------------------" << endl << endl;
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}

void optionselect() // Function that recieves the input from the user on the main menu
{
    cin >> menuopt;
    cin.get();
    system("cls");
}

void option2() // Function thats used if user selects credits
{
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 5);
    cout << endl << endl << endl << endl << endl << endl << endl << endl;
    cout << "                                                   ------------------------------------------------" << endl;
    cout << "                                                   |              Made by Dylan Taine             |" << endl;
    cout << "                                                                                                   " << endl;
    cout << "                                                   |                                              |" << endl;
    cout << "                                                                  Thanks for playing               " << endl;
    cout << "                                                   |                                              |" << endl;
    cout << "                                                                                                   " << endl;
    cout << "                                                   |                                              |" << endl;
    cout << "                                                                                                   " << endl;
    cout << "                                                   |    Press [Enter] to go back to main menu     |" << endl;
    cout << "                                                                                                   " << endl;
    cout << "                                                   |                                              |" << endl;
    cout << "                                                   ------------------------------------------------" << endl << endl;
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
    cin.get();
    system("cls");
}

void checkbet() // Function that checks if the bet amount exceeds their total money or is equal to 0 or less
{
    while (1)
    {
        if (betcash > totalcash || betcash <= 0)
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            system("cls");
            cout << endl << endl << endl << endl << endl << endl << endl << endl;
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 5);
            cout << "                                                   ------------------------------------------------" << endl;
            cout << "                                                   |                  Balance: " << totalcash << "               |" << endl;
            cout << "                                                                                                   " << endl;
            cout << "                                                   |                                              |" << endl;
            cout << "                                                            Please enter an allowed amount:        " << endl;
            cout << "                                                   |                                              |" << endl;
            cout << "                                                                                                   " << endl;
            cout << "                                                   |                                              |" << endl;
            cout << "                                                                                                   " << endl;
            cout << "                                                   |                                              |" << endl;
            cout << "                                                                                                   " << endl;
            cout << "                                                   |                                              |" << endl;
            cout << "                                                   ------------------------------------------------" << endl << endl;
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
            cout << "" << endl;
            cin >> betcash;
            system("cls");
        }
        else
            break;
    }
}


int main()
{
    HWND console = GetConsoleWindow();
    RECT r;
    GetWindowRect(console, &r); //stores the console's current dimensions
    MoveWindow(console, r.left, r.top, 1200, 600, TRUE); // changing the dimensions of the console

    bool gamerun = true; // Used to keep the game looping untill the user chooses to close
    void loop(); // Main game loop
    {

        do
        {
            menu();
            optionselect();

            if (menuopt == 1) // This is the section for the slot machine play
            {
                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 5);
                cout << endl << endl << endl << endl << endl << endl << endl << endl;
                cout << "                                                   ------------------------------------------------" << endl;
                cout << "                                                   |                  Balance: " << totalcash << "               |" << endl;
                cout << "                                                                                                   " << endl;
                cout << "                                                   |                                              |" << endl;
                cout << "                                                                      Bet now:                     " << endl;
                cout << "                                                   |                                              |" << endl;
                cout << "                                                                                                   " << endl;
                cout << "                                                   |                                              |" << endl;
                cout << "                                                                                                   " << endl;
                cout << "                                                   |                                              |" << endl;
                cout << "                                                                                                   " << endl;
                cout << "                                                   |                                              |" << endl;
                cout << "                                                   ------------------------------------------------" << endl << endl;
                SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
                cin >> betcash;

                checkbet(); //checking bet validity here 

                cin.get();
                system("cls");
                srand(time(NULL));

                a = (rand() % 5) + 1;
                b = (rand() % 5) + 1;
                c = (rand() % 5) + 1;

                if (a == 7 && a == b && a == c) // If all numbers match 7
                {
                    x10();
                    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 5);
                    cout << endl << endl << endl << endl << endl << endl << endl << endl;
                    cout << "                                                   ------------------------------------------------" << endl;
                    cout << "                                                   |                 [" << a << "]" << "[" << b << "]" << "[" << c << "]                    |" << endl;
                    cout << "                                                                                                   " << endl;
                    cout << "                                                   |                                              |" << endl;
                    cout << "                                                                 You have won: " << x10bet << "               " << endl;
                    cout << "                                                   |                                              |" << endl;
                    cout << "                                                                                                   " << endl;
                    cout << "                                                   |    Press [Enter] to go back to main menu     |" << endl;
                    cout << "                                                                                                   " << endl;
                    cout << "                                                   |                                              |" << endl;
                    cout << "                                                                                                   " << endl;
                    cout << "                                                   |                                              |" << endl;
                    cout << "                                                   ------------------------------------------------" << endl << endl;
                    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
                    cin.get();
                    system("cls");
                }
                else
                {
                    if (a == b && a == c) // If all numbers match
                    {
                        x5();
                        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 5);
                        cout << endl << endl << endl << endl << endl << endl << endl << endl;
                        cout << "                                                   ------------------------------------------------" << endl;
                        cout << "                                                   |                 [" << a << "]" << "[" << b << "]" << "[" << c << "]                    |" << endl;
                        cout << "                                                                                                   " << endl;
                        cout << "                                                   |                                              |" << endl;
                        cout << "                                                                You have won: " << x5bet << "                 " << endl;
                        cout << "                                                   |                                              |" << endl;
                        cout << "                                                                                                   " << endl;
                        cout << "                                                   |    Press [Enter] to go back to main menu     |" << endl;
                        cout << "                                                                                                   " << endl;
                        cout << "                                                   |                                              |" << endl;
                        cout << "                                                                                                   " << endl;
                        cout << "                                                   |                                              |" << endl;
                        cout << "                                                   ------------------------------------------------" << endl << endl;
                        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
                        cin.get();
                        system("cls");
                    }
                    else if (a == b || b == c || a == c) // If any two numbers match
                    {
                        x3();
                        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 5);
                        cout << endl << endl << endl << endl << endl << endl << endl << endl;
                        cout << "                                                   ------------------------------------------------" << endl;
                        cout << "                                                   |                 [" << a << "]" << "[" << b << "]" << "[" << c << "]                    |" << endl;
                        cout << "                                                                                                   " << endl;
                        cout << "                                                   |                                              |" << endl;
                        cout << "                                                                  You have won: " << x3bet << "                 " << endl;
                        cout << "                                                   |                                              |" << endl;
                        cout << "                                                                                                   " << endl;
                        cout << "                                                   |    Press [Enter] to go back to main menu     |" << endl;
                        cout << "                                                                                                   " << endl;
                        cout << "                                                   |                                              |" << endl;
                        cout << "                                                                                                   " << endl;
                        cout << "                                                   |                                              |" << endl;
                        cout << "                                                   ------------------------------------------------" << endl << endl;
                        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
                        cin.get();
                        system("cls");
                    }
                    else // No matching numbers 
                    {
                        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
                        cout << endl << endl << endl << endl << endl << endl << endl << endl;
                        cout << "                                                   ------------------------------------------------" << endl;
                        cout << "                                                   |                 [" << a << "]" << "[" << b << "]" << "[" << c << "]                    |" << endl;
                        cout << "                                                                                                   " << endl;
                        cout << "                                                   |                                              |" << endl;
                        cout << "                                                                  You have lost: " << betcash << "                " << endl;
                        cout << "                                                   |                                              |" << endl;
                        cout << "                                                                                                   " << endl;
                        cout << "                                                   |    Press [Enter] to go back to main menu     |" << endl;
                        cout << "                                                                                                   " << endl;
                        cout << "                                                   |                                              |" << endl;
                        cout << "                                                                                                   " << endl;
                        cout << "                                                   |                                              |" << endl;
                        cout << "                                                   ------------------------------------------------" << endl << endl;
                        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
                        losscash();
                        cin.get();
                        system("cls");
                    }
                }
            }
            else if (menuopt == 2) // Shows credits
            {
                option2();
            }
            else if (menuopt == 3) // Closes game 
            {
                gamerun = false;
            }

        } while (gamerun == true);
    }
    return (0);
}